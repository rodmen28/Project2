
public interface Combat {
	int attack();
	int dropHP();
}
