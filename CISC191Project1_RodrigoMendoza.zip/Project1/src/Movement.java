
public interface Movement {

	public abstract void setMove(int inMove);
	   public abstract int getMove();
	   public abstract int calcMove();
}
